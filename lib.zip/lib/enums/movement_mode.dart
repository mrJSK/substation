// lib/enums/movement_mode.dart
enum MovementMode { bay, text, energyText, busbarLength }
